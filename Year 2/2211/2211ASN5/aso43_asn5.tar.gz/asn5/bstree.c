// CS2211a 2023, Section 1
// Assignment 5
// Allison So
// 251087238
// aso43
// 11/29/2023
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "bstree.h"

BStree bstree_ini(void) {
        BStree new = (BStree)malloc(sizeof(BStree_node));
       	*new = NULL;
	return new;
}

BStree_node* new_node(Key key, Data data) {
	//helper function to create a pointer to a tree node from key and data
	BStree_node* new = (BStree_node*)malloc(sizeof(BStree_node));
	new->key = key_ini();
	key_set(new->key, key->key1, key->key2);
	new->data = data_ini();
	new->left = NULL;
	new->right = NULL;
	return new;
}

void bstree_insert(BStree bst, Key key, Data data) {
	if (*bst==NULL) {

                *bst = new_node(key, data);
        }
        else {  
                if (bstree_search(bst, key)==NULL) {	
			int kvb = key_comp(key, (*bst)->key);
                	if (kvb==0) {
				return;
			}
			if (kvb>0) {
				bstree_insert(&((*bst)->right), key, data); 
			}
			else {
				bstree_insert(&((*bst)->left), key, data);
			}
		}
        }
}

Data bstree_search(BStree bst, Key key) {
	if (*bst==NULL) {
                return NULL;
        }
        else {
                int kvb = key_comp(key, (*bst)->key);
                if (kvb==0) {
                        return (*bst)->data;
                }
                if (kvb>0) {
		       bstree_search(&((*bst)->right), key); 
		}
		else {
			bstree_search(&((*bst)->left), key);
		}
        }
}

void bstree_traverse(BStree bst) {
	printf("Number	Street	Occurrence\n");
	if (*bst!=NULL) {
		bstree_traverse(&((*bst)->left));
		key_print2((*bst)->key);
		data_print((*bst)->data);
		bstree_traverse(&((*bst)->right));
	}

}

void bstree_free(BStree bst) {
	while (*bst!=NULL) {
                bstree_free(&((*bst)->left));
                bstree_free(&((*bst)->right));
		key_free((*bst)->key);
		data_free((*bst)->data);
     		free(*bst);
        }
	free(*bst);
	*bst = NULL;
	
}
