// CS2211a 2023, Section 1
// Assignment 5
// Allison So
// 251087238
// aso43
// 11/29/2023
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "matrix.h"

Matrix matrix_construction(void) {
	return bstree_ini();
}

unsigned char matrix_index_in(Matrix m, Index1 index1, Index2 index2) {
	Key check = key_ini();
	key_set(check, index1, index2);
	Data node = bstree_search(m, check);
	if (node!=NULL) {
		return 1;
	}
	return 0;
}

const Value *matrix_get(Matrix m, Index1 index1, Index2 index2) {
	Key check = key_ini();
	key_set(check, index1, index2);
        Data node = bstree_search(m, check);
        if (node!=NULL) {
                return node;
        }
        return NULL;
}

void matrix_set(Matrix m, Index1 index1, Index2 index2, Value value) {
	Key set = key_ini();
        key_set(set, index1, index2);
        bstree_insert(m, set, &value);
}

void matrix_list(Matrix m) {
	bstree_traverse(m);
}

void matrix_destruction(Matrix m) {
	bstree_free(m);
}
