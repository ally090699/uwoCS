// CS2211a 2023, Section 1
// Assignment 5
// Allison So
// 251087238
// aso43
// 11/29/2023
//
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "matrix.h"

void main() {
    	char input[250];
	int inInt, type;
	char strIn1[250], strIn2[250];
	Matrix new = matrix_construction();
	int key2;
	char key1_1[250], key1_2[250];
	char line[250];
	int occurrences=0;
	
	printf("Enter 1 to read from file or 2 for manual input. Enter any other key to quit.: \n");
        scanf("%d", &type);
        if (type==1) {	
		printf("Enter the filename: ");
		scanf("%s", input);
		printf("%s", input);
		FILE *file = fopen(input, "r");
		if (file!=NULL) {
			
			while(fgets(line, sizeof(line), file) != NULL) {
				if (sscanf(line, "%d %s %s", &key2, strIn1, strIn2) == 3) {
					strcat(key1_1, key1_2);
					if (matrix_index_in(new, key1_1, key2)==1) {
						occurrences++;					
					}
					else {
						strcat(key1_1, key1_2);
						Data newData = data_ini();
						data_set(newData, occurrences);
						matrix_set(new, key1_1, key2, *newData);
					}
					key1_1[0] = '\0';
				}
			}
			fclose(file);
		}
		matrix_list(new);
        	matrix_destruction(new);
        	return;
	}		
	else if (type==2) {
		int num;
		char str[250];
		bool check = false;
		printf("Enter data. Enter 'quit' to quit program.\n");
  	        while (fgets(str, sizeof(str), stdin) != NULL) {
			if (strcmp(str, "quit\n")==0) {
				break;
			}
			if (sscanf(str, "%d", &num) == 1) {

            			if (sscanf(str, "%*d %s %s", strIn1, strIn2) == 2) {
					strcat(strIn1, " ");
					strcat(strIn1, strIn2);
                        		if (matrix_index_in(new, strIn1, key2)==1) {
                        		        occurrences++;
					}       
                        		else {
						Data newData = data_ini();
                        		        data_set(newData, occurrences);
                        		        matrix_set(new, strIn1, key2, *newData);
                        		}
					strIn1[0] = '\0';
				}	
			}
		}
		matrix_list(new);
        	matrix_destruction(new);
        	return;
	}
	return;
}
