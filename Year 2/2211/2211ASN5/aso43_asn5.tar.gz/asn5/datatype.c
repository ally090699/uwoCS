// CS2211a 2023, Section 1
// Assignment 5
// Allison So
// 251087238
// aso43
// 11/29/2023
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "datatype.h"

Key key_ini() {
        Key new = (Key)malloc(sizeof(Key_struct));
        new->key1 = NULL;
        new->key2 = 0;
        return new;
}

void key_set(Key key, Key1 key1, Key2 key2) {
        key->key1 = (Key1)malloc(strlen(key1) + 1);
	strcpy(key->key1, key1);
        key->key2 = key2;
}

int key_comp(Key key1, Key key2) {
        int kvk = strcmp(key1->key1,key2->key1);
	if (kvk!=0) {
                return kvk;
        }
        else {
                if (key1->key2 > key2->key2) {
                        return 1;
                }
                else if (key1->key2 == key2->key2) {
                        return 0;
                }
                else {
                        return -1;
                }
        }
}

void key_print1(Key key) {
        printf("%s, %d\n", key->key1, key->key2);
}

void key_print2(Key key) {
        printf("%d	%s	", key->key2, key->key1);
}

void key_free(Key key) {
        free(key->key1);
        free(key);
}

Data data_ini() {
        Data new = (Data)malloc(sizeof(float));
        *new = 0.0;
        return new;
}

void data_set(Data data, float intdata) {
        *data = intdata;
}

void data_print(Data data) {
        printf("%f\n", *data);
}

void data_free(Data data) {
        free(data);
}

