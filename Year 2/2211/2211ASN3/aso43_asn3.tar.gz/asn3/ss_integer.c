#include <stdio.h>
#include <stdbool.h>

void main() {
	int input;
	bool isComplete = false;
	while (!isComplete) {
		printf("Enter an integer: ");
		scanf("%d", &input);

		const char segements[10][3][3] =
			{ { {' ', '_', ' '}, {'|', ' ', '|'}, {'|', '_', '|'} },
			{ {' ', ' ', ' '}, {' ', '|', ' '}, {' ', '|', ' '} }, 
			{ {' ', '_', ' '}, {' ', '_', '|'}, {'|', '_', ' '} },
			{ {' ', '_', ' '}, {' ', '_', '|'}, {' ', '_', '|'} }, 
			{ {' ', ' ', ' '}, {'|', '_', '|'}, {' ', ' ', '|'} }, 
			{ {' ', '_', ' '}, {'|', '_', ' '}, {' ', '_', '|'} }, 
			{ {' ', '_', ' '}, {'|', '_', ' '}, {'|', '_', '|'} }, 
			{ {' ', '_', ' '}, {' ', ' ', '|'}, {' ', ' ', '|'} }, 
			{ {' ', '_', ' '}, {'|', '_', '|'}, {'|', '_', '|'} }, 
			{ {' ', '_', ' '}, {'|', '_', '|'}, {' ', '_', '|'} }};
		
		for (int i=0; i<10; i++) {
			if (input==i) {
				for (int j=0; j<3; j++) {
					for (int k=0; k<3; k++) {
						printf("%c", segements[i][j][k]);
					}
					printf("\n");
				}
			}
		}

		char cont;
		printf("Would you like to continue? Y(Yes) N(No) ");
		scanf(" %c", &cont);
		if (cont=='Y') {
			isComplete = false;
		}
		else if (cont=='N') {
			isComplete = true;
		}
	}
}
