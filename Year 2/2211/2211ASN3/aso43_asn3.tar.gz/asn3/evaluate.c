#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

char get_op(void) {
	char op;
	scanf(" %c", &op);
	if (op=='+') {
		return '+';
	}
	else if (op=='-') {
		return '-';
	}
	else if (op=='\\') {
		return '\\';
	}
	else {
		printf("Enter an operation: ");
		return get_op();
	}
}

float get_num(void) {
	float num;
	scanf("%f", &num);
	return num;
}

float sub_sim_exp(float sub_exp) {
	printf("Enter an operation: ");
	char next_op = get_op();
	if (next_op=='\\') {
		return sub_exp;
	}
	else if (next_op=='+' || next_op=='-') {
		printf("Enter another number: ");
		int next_num = get_num();
		if (next_op=='+') {
			sub_exp = sub_exp + next_num;
		}
		else if (next_op=='-') {
                        sub_exp = sub_exp - next_num;
                }
		return sub_sim_exp(sub_exp);
	}
	exit(EXIT_FAILURE);
}

float sim_exp(void) {
	float num = get_num();
	return sub_sim_exp(num);	
}

void main() {
	float result;
	bool isComplete = false;
	printf("Enter the first number in your simple arithmetic expression: ");
	result = sim_exp();
	char check;
	while (!isComplete) {
		printf("Would you like to continue? Y (Yes) N (No)\n");
		scanf(" %c", &check);
		if (check=='Y') {
			result = sub_sim_exp(result);
			printf("Your simple arithmetic expression gives: %f\n", result);
			isComplete = false;
		}
		else if (check=='N') {
			printf("Your simple arithmetic expression gives: %f\n", result);
			isComplete = true;
		}
		else {
        		printf("Invalid input. Please enter Y or N.\n");
        		isComplete = false;
		}
	}
}
