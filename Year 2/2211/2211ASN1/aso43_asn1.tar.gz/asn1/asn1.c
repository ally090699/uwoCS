// CS2211 2023
// Assignment 1
// Allison So
// 251087238
// aso43
// September 18, 2023
#include <stdio.h>
int main ( )
{
printf ("Hello, CS2211 2023!\n");
return 0;
}
