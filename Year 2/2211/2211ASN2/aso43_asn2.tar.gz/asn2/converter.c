#include <stdio.h>
#include <stdbool.h>
// Allison So
// 251087238
// CS2211
// Assignment 2

void CToF() {
	float value, final;
	printf("Input the value you would like to convert: ");
	scanf("%f", &value);
	printf("%f Celsius in Fahrenheit: %f\n", value, value + 32);
}

float FToC() {
	float value, final;
	printf("Input the value you would like to convert: ");
        scanf("%f", &value);
        printf("%f Fahrenheit in Celsius: %f\n", value, value - 32);
}

float CmToInch() {
	float value;
	printf("Input the value you would like to convert: ");
        scanf("%f", &value);
        printf("%f Centimeters in Inches: %f\n", value, value * 0.393701);
}

float InchToCm() {
	float value;
	printf("Input the value you would like to convert: ");
        scanf("%f", &value);
	printf("%f Inches in Centimeters: %f\n", value, value / 0.393701);
}

float KmToMile() {
	float value;
	printf("Input the value you would like to convert: ");
        scanf("%f", &value);
	printf("%f Kilometers in Miles: %f\n", value, value / 1.60934);
}

float MileToKm() {
	float value;
	printf("Input the value you would like to convert: ");
        scanf("%f", &value);
	printf("%f Miles in Kilometers: %f\n", value, value * 1.60934);
}

float GalToLit() {
	float value;
	printf("Input the value you would like to convert: ");
        scanf("%f", &value);
	printf("%f Gallons in Liters: %f\n", value, value * 3.785412);
}

float LitToGal() {
	float value;
	printf("Input the value you would like to convert: ");
        scanf("%f", &value);
	printf("%f Liters in Gallons: %f\n", value, value / 3.785412);
}

void CFConvert() {
	char input; bool isComplete = false;
	while (!isComplete) {
		printf("Enter the character corresponding to the option you would like to select.\nC for conversion from Celsius to Fahrenheit\nF for conversion from Fahrenheit to Celsius\n");
		scanf(" %c", &input);
		if (input=='C') {		
			CToF();
			isComplete = true;
		}
		else if (input=='F') {
			FToC(); 
			isComplete = true;
		}
		else {
			continue;
		}
	}
}

void CmInchConvert() {
	char input; bool isComplete = false;
	while (!isComplete) {
		printf("Enter the character corresponding to the option you would like to select.\nC for conversion from Centimetre to Inch\nI for conversion from Inch to Centimetre\n");
		scanf(" %c", &input);
		if (input=='C') {		
			CmToInch();
			isComplete = true;
		}
		else if (input=='I') {
			InchToCm(); 
			isComplete = true;
		}
		else {
			continue;
		}
	}
}

void KmMileConvert() {
	char input; bool isComplete = false;
	while (!isComplete) {
		printf("Enter the character corresponding to the option you would like to select.\nK for conversion from Kilometer to Mile\nM for conversion from Mile to Kilometer\n");
		scanf(" %c", &input);
		if (input=='K') {		
			KmToMile();
			isComplete = true;
		}
		else if (input=='M') {
			MileToKm(); 
			isComplete = true;
		}
		else {
			continue;
		}
	}
}

void GalLitConvert() {
	char input; bool isComplete = false;
	while (!isComplete) {
		printf("Enter the character corresponding to the option you would like to select.\nG for conversion from Gallon to Liter\nL for conversion from Liter to gallon\n");
		scanf(" %c", &input);
		if (input=='G') {		
			GalToLit();
			isComplete = true;
		}
		else if (input=='L') {
			LitToGal(); 
			isComplete = true;
		}
		else {
			continue;
		}
	}
}

void main() {		
	int input; bool isComplete = false;
	while (!isComplete) {
		printf("Enter the number corresponding to the option you would like to select. \n1 for conversion between Celsius and Fahrenheit\n2 for conversion between Centimetre and Inch\n3 for conversion between Kilometer and Mile\n4 for conversion between Gallon and Liter\n0 for quit\n");
		scanf(" %d", &input);
		if (input==0) {
			break;
		}
		else if (input==1) {
			CFConvert();
			isComplete = true;
		}
		else if (input==2) {
			CmInchConvert();
			isComplete = true;
		}
		else if (input==3) {
			KmMileConvert();
			isComplete = true;
		}
		else if (input==4) {
			GalLitConvert();
			isComplete = true;
		}
		else {
			continue;
		}
	}
}

