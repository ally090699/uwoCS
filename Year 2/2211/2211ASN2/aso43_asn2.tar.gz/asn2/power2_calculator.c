#include <stdio.h>

unsigned long PowerOfTwo(int exp) {
	if (exp==0) {
		return 1;
	}
	else {
		return 2*PowerOfTwo(exp-1);
	}
}
void main() {
	int input;
	unsigned long result;
	while (input!=-1) {
		printf("Enter an exponent. Note that it should be a non-negative integer number. Enter -1 to quit.\n");
		scanf("%d", &input);
		if (input==0) {
			printf("2^0: 1\n");
		}
		else if (input==-1) {
			break;
		}
		else {
			result = PowerOfTwo(input);
			printf("2^%d: %ld\n", input, result);
		}
	}
}
