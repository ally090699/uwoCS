// CS2211a 2023, Section 1
// Assignment 4
// Allison So
// 251087238
// aso43
// 11/13/2023
//
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "bst.h"
BStree bstree_ini(int size) {
	//allocates memory for members tree_nodes and is_free, setting all entries of is_free to 1
	BStree newTree;
	newTree.tree_nodes = (Node *)malloc((size+1)*sizeof(Node));
	newTree.is_free = (unsigned char *)malloc((size+1)*sizeof(unsigned char));
	newTree.size = size;
	
	for (int i=0; i<=size; i++) {
		newTree.is_free[i] = 1;
	}
	
	return newTree;	
}
void bstree_insert(BStree bst, Key key, int data) {
	//the given data with key are inserted into bst unless key is already in bst
	int index = 1;
	for (int i = 1; i<=bst.size; i++) {
		if (!bst.is_free[i]) {
			int kvn = key_comp(key, bst.tree_nodes[i].key);
			if (kvn==0) {
                                return;
                        }
			else if (kvn<0) {
				index = 2*i;
			}
			else {
				index = 2*i + 1;
			}
		}
	}

	if (index<=bst.size) {
		bst.is_free[index] = 0;
		bst.tree_nodes[index].key = key;
		bst.tree_nodes[index].data = data;
	}
}

void inorder_traversal(Node *tree_nodes, int root) {
	//prints tree nodes in order traversal ; helper function
	if ((root>0)&&!(!tree_nodes[root].data)) {
		int left = 2*root;
		int right = 2*root + 1;
		inorder_traversal(tree_nodes, left);
		printf("The data is %d\n", tree_nodes[root].data);
		inorder_traversal(tree_nodes, right);
	}
}
void bstree_traversal(BStree bst) {
	//prints tree nodes in order traversal
	inorder_traversal(bst.tree_nodes, 1);
}
void bstree_free(BStree bst) {
	//all dynamic memory used by bst are freed
	free(bst.tree_nodes);
	free(bst.is_free);
}
