#include <stdio.h>

long long factorial(int n) {
    if (n == 0 || n == 1) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

double calculate_e(double epsilon) {
    double e = 1.0;
    double term = 1.0;
    long long fact;
    int n = 1;

    while (term >= epsilon) {
        fact = factorial(n);
        term = 1.0 / fact;
        e += term;
        n++;
    }

    return e;
}

int main() {
	double input, result;
	printf("Input epsilon value: ");
	scanf("%lf", &input);
	result = calculate_e(input);
	printf("Approximation of e with epsilon = %e: %lf\n", input, result);
}
