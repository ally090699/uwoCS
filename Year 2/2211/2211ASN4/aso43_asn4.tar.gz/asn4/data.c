// CS2211a 2023, Section 1
// Assignment 4
// Allison So
// 251087238
// aso43
// 11/13/2023
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"
Key key_construct(char *in_name, int in_num) {
	//creates a key object with the given name and number
	Key newKey;
	newKey.name = (char *)malloc(strlen(in_name)+1);
	strcpy(newKey.name, in_name);
	newKey.num = in_num;
	return newKey;
}
int key_comp(Key key1, Key key2) {
	//Compares key1 to key2, returning 0 if equal, 1 if key1 is greater and -1 otherwise
	int return_key, return_num;
	return_key = strcmp(key1.name, key2.name);
	if (return_key==0) {
		if (key1.num == key2.num) {
			return_num = 0;
		}
		else if (key1.num > key2.num) {
			return_num = 1;
		}
		return_num = -1;
	}
	else {
		if (return_key > 0) {
			return_key = 1;
		}
		return_key = -1;
	}
	
	if ((return_key==0)&&(return_num==0)) {
		return 0;
	}
	return return_key;
}

void print_key(Key key) {
	//prints key name and number
	printf("The number is %d and the name of the key is %s.\n", key.num, key.name);
}

void print_node(Node node) {
	//prints node's data
	print_key(node.key);
	printf("The data is %d\n", node.data);
}
