#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

int seatMap[10][100] = {0};	
pthread_mutex_t seatMutex[10][100];

typedef struct{
	int customerID;
	int seats[100][2];
} seatRequest;

void *checkAvailable(void *req){
	seatRequest *request = (seatRequest *)req;
	int customerID = request->customerID;
	char success[1024] = "";
	char failure[1024] = "";
	int successful = 1;
	pthread_mutex_t successLock[100];
	int successfulLock = 0;

	for (int i=0; i<100; i++){
		int aisle = request->seats[i][0];
		int seat = request->seats[i][1];

		if (aisle==-1 || seat==-1){
			break;
		}
		
		if (pthread_mutex_trylock(&seatMutex[aisle][seat])==0){
			if (seatMap[aisle][seat]==0){	//if seat is available
				successLock[successfulLock] = seatMutex[aisle][seat];
				successfulLock++;
				sprintf(success + strlen(success), "Aisle %d, Seat %d, ", aisle, seat);
			} else{	//if seat unavailable
				sprintf(failure + strlen(failure), "Aisle %d, Seat %d, ", aisle, seat);
				successful = 0;
				pthread_mutex_unlock(&seatMutex[aisle][seat]);
			}
		} else{	//trylock failed
			sprintf(failure + strlen(failure), "Aisle %d, Seat %d, ", aisle, seat);
                        successful = 0;
		}
	}

	if (successful){
                sleep(1);

		printf("Customer %d - Successful - %s\n", customerID, success);
                for (int i=0; i<successfulLock; i++){
                        int aisle = request->seats[i][0];
                        int seat = request->seats[i][1];
                        seatMap[aisle][seat] = customerID;
			pthread_mutex_unlock(&successLock[i]);
                }

	}else {
		printf("Customer %d - Fail - %s\n", customerID, failure);
		for (int i=0; i<successfulLock; i++){
                        pthread_mutex_unlock(&successLock[i]);
                }

	}
	
	free(request);
	return NULL;
}

void main(int check, char *flag[]){
        char *filename;

	if (check==2){
                filename = flag[1];
        } else{
		printf("Incorrect usage: <filename>\n");
	}

	FILE *file = fopen(filename, "r");
	if (file==NULL){
		printf("Error: File cannot be opened.\n");
		return;
	}

	for (int i=0; i<10; i++){
		for (int j=0; j<100; j++){	//for each seat in each aisle, create mutexes
			pthread_mutex_init(&seatMutex[i][j], NULL);
		}
	}

	pthread_t threads[50];
	int threadNum = 0;
	char line[1024];

	while (fgets(line, sizeof(line), file)){

		seatRequest *request = malloc(sizeof(seatRequest));
		
		if (!request){
			printf("Error: Failed to allocate memory.\n");
			fclose(file);
			return;
		}

		if (line[0]=='#' || line[0]=='\n'){
			continue;
		}
		
		char *lineIn = strtok(line, ",");
		if (atoi(lineIn)==0){
			continue;
		}
		request->customerID = atoi(lineIn);	//first token is the customer ID
		
		int reqInd = 0;

		while ((lineIn = strtok(NULL, ","))!=NULL){
			int aisle = atoi(lineIn);
			lineIn = strtok(NULL, ",");
			int seat = atoi(lineIn);
			
			request->seats[reqInd][0] = aisle;
			request->seats[reqInd][1] = seat;
			reqInd++;
		}

		if (reqInd<100){
			request->seats[reqInd][0] = -1;
			request->seats[reqInd][1] = -1;
		}

		pthread_create(&threads[threadNum], NULL, checkAvailable, request);
		threadNum++;
	}

	fclose(file);

	for (int i=0; i<threadNum; i++){
		pthread_join(threads[i], NULL);
	}

	for (int i=0; i<10; i++){
		for (int j=0; j<100; j++){
			pthread_mutex_destroy(&seatMutex[i][j]);
		}
	}
	
	printf("          1   2   3   4   5   6   7   8   9  10  11  12\n");
	
	for (int i=1; i<=5; i++){
		printf("Aisle %d ", i);
		for (int j=1; j<=12; j++){
			if (seatMap[i][j]==0){
				printf("000 ");
			} else{
				printf("%3d ", seatMap[i][j]);
			}
		}
		printf("\n");
	}

	return;

}
