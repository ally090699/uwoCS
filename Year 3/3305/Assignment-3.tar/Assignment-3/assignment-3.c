#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>
#include <semaphore.h>

int maxNum, numThreads;
int numPrimes = 0;
int sumPrimes = 0;
sem_t mutex;

bool is_prime(int num) {
	int count = 0;
	if (num<=1){ 
		return false;
	}
	else {
		for (int i=2; i * i <= num; i++){
			if (num % i == 0) {
				count++;
			}
		}
		if (count>0) {
			return false;
		}
		return true;
	}
}

void *countPrimes(void *threadID){
	// thread-independent calculations
	int threadNum = *(int *) threadID;
	int range = maxNum / numThreads;
	int start = threadNum * range;
	int end = (threadNum == numThreads - 1) ? maxNum : (threadNum + 1) * range;

	int count = 0;
	int sum = 0;
	
	printf("Thread # %d is finding primes from low = %d to high = %d\n", threadNum, start, end);

	for (int i=start; i<end; i++){
		if (is_prime(i)) {
			count++;
			sum+=i;
		}
	}

	sem_wait(&mutex);	// wait
	numPrimes += count;	
	sumPrimes += sum;
	printf("Thread # %d Sum is %d, Count is %d\n", threadNum, sum, count);
	sem_post(&mutex);	// signal
	
	pthread_exit(0);
}

void main(int check, char *flag[]){
        int isValid = 0;

	if (check==3){
                numThreads = atoi(flag[1]);
                maxNum = atoi(flag[2]);

		if (numThreads>0 || maxNum>0 || maxNum<1000000){
			isValid = 1;
			
			pthread_t threads[numThreads];
			int threadNum[numThreads];
			sem_init(&mutex, 0, 1);

			for (int i=0; i<numThreads; i++){
				threadNum[i] = i;
				if (pthread_create(&threads[i], NULL, countPrimes, &threadNum[i])){
					printf("Error while creating thread.\n");
				}
			}

			for (int i=0; i<numThreads; i++){
				if (pthread_join(threads[i], NULL)) {
					printf("Error joining threads.\n");
				}
			}
			
			printf("\n\t\tGRAND SUM IS %d, COUNT IS %d\n", sumPrimes, numPrimes);
			sem_destroy(&mutex);
			return;

		}
		else{
			printf("Invalid input. Input must be positive integers. The maximum number range handled is 1,000,000.\n");
			return;
        	}
	}
	else {
		printf("Invalid input. <number_of_threads> <max_num_range>\n");
		return;
	}
}
