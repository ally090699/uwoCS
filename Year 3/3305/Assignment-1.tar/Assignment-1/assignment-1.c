#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "checkPassword.h"
#include <sys/wait.h>

int main(int check, char *flag[]){
	int forkEnabled = 0;
	pid_t i, j, pid;

	if (check>1 && strcmp(flag[1], "-f")==0){
		forkEnabled = 1;
	}
	
	if (forkEnabled==0){
		char password[13];
		password[12]='\0';
		char guess[4];
		guess[3]='\0';

		printf("Process %d with parent %d cracking the password...\n", getpid(), getppid());
		
		for (int i=0; i<12; i+=3){	
			for (char g1=33; g1<=126; g1++){
				for (char g2=33; g2<=126; g2++){
					for (char g3=33; g3<=126; g3++){
						guess[0]=g1;
						guess[1]=g2;
						guess[2]=g3;
						
						if (checkPassword(guess, i)==0){
							strncpy(&password[i],guess,3);
							printf("Process %d with parent %d finds %d-%d: %s\n", getpid(), getppid(), i, i+2, guess);
							break;
						}
					}
				}
			}
		}
	} else{
		printf("Process %d with parent %d cracking the password...\n",getpid(),getppid());
		for (int k=0; k<4; k++){			
			char password[13];
                	password[12]='\0';
                	char guess[4];
                	guess[3]='\0';
			
			pid=fork();
			
			if (pid<0){
				printf("Fork unsuccessful.\n");
			} else if (pid==0){	//if child process

	                        for (char g1=33; g1<=126; g1++){
	                               	for (char g2=33; g2<=126; g2++){
	                                       	for (char g3=33; g3<=126; g3++){
	                                               	guess[0]=g1;
       		                                        guess[1]=g2;
       	        	                                guess[2]=g3;

                        	                        if (checkPassword(guess, k*3)==0){
                                	                       	strncpy(&password[k*3],guess,3);
                                        	               	printf("Process %d with parent %d finds %d-%d: %s\n", getpid(), getppid(), k*3, (k*3)+2, guess);
                                                	       	exit(0);
                                                	}
                                        	}
					}
                        	}
                	}
		}

		for (int i=0; i<4; i++){
			wait(NULL);
		}
	}
}
