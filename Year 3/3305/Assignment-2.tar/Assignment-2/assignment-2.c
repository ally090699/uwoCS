#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

int main(int check, char *input[]){
        if (check>2){
		if (strlen(input[1])==4 && strlen(input[2])==4){
			int n = strlen(input[1]);
			int procOne = atoi(input[1]);
			int procTwo = atoi(input[2]);

			if (procOne>9999 || procOne<1000){
				printf("First input is outside the valid range.\n");
			} else if (procTwo>9999 || procTwo<1000){
				printf("Second input is outside the valid range.\n");
			}
			
			printf("Your integers are %d %d.\n", procOne, procTwo);
			
			int a1 = procOne / 100;
			int a2 = procOne % 100;
			int b1 = procTwo / 100;
			int b2 = procTwo % 100;
			int ports[2][2];
			pid_t pid;

			if (pipe(ports[0]) < 0 || pipe(ports[1]) < 0){
				printf("Error creating pipe.\n");
				exit(0);
			}
			pid = fork();
			
			int aa1, aa2, bb1, bb2, a, A, b, B, c, C, d, D, X, Y, Z;

			if (pid<0){
				printf("Fork unsuccessful.\n");
				exit(0);
                        } else if (pid>0){     // parent
				printf("Parent (PID %d): created child (PID %d)\n", getpid(), pid);
        	                printf("\n###\n# Calculating X\n###\n");
	
				//one - parent send a1 and b1 to child through pipe
				printf("Parent (PID %d): Sending %d to child\n", getpid(), a1);
				write(ports[0][1],&a1,sizeof(a1));

				printf("Parent (PID %d): Sending %d to child\n", getpid(), b1);
				write(ports[0][1],&b1,sizeof(b1));

				//Calculate X
				read(ports[1][0],&A,sizeof(A));
				printf("Parent (PID %d): Received %d from child\n", getpid(), A);
				X = A*pow(10,n);
				

				printf("\n###\n# Calculating Y\n###\n");
				//three - parent send a1 and b2 to child through pipe
				printf("Parent (PID %d): Sending %d to child\n", getpid(), a1);
				write(ports[0][1], &a1, sizeof(a1));

				printf("Parent (PID %d): Sending %d to child\n", getpid(), b2);
                                write(ports[0][1], &b2, sizeof(b2));

                                read(ports[1][0],&C,sizeof(C));
                                printf("Parent (PID %d): Received %d from child\n", getpid(), C);
                                
				printf("Parent (PID %d): Sending %d to child\n", getpid(), a2);
                                write(ports[0][1], &a2, sizeof(a2));

                                printf("Parent (PID %d): Sending %d to child\n", getpid(), b1);
                                write(ports[0][1], &b1, sizeof(b1));

				read(ports[1][0],&B,sizeof(B));
                                printf("Parent (PID %d): Received %d from child\n", getpid(), B);

				Y = (B+C)*pow(10,(n/2));

				printf("\n###\n# Calculating Z\n###\n");
                                //parent send a2 and b2 to child through pipe
                                printf("Parent (PID %d): Sending %d to child\n", getpid(), a2);
                                write(ports[0][1], &a2, sizeof(a2));

                                printf("Parent (PID %d): Sending %d to child\n", getpid(), b2);
                                write(ports[0][1], &b2, sizeof(b2));

				read(ports[1][0],&D,sizeof(D));
                                printf("Parent (PID %d): Received %d from child\n", getpid(), D);

                                Z = D*pow(10,0);

				printf("%d*%d == %d + %d + %d == %d\n", procOne, procTwo, X, Y, Z, X+Y+Z);


			} else{			// child
				// two - child multiply a1 and b1, send A to parent through pipe
				read(ports[0][0],&aa1,sizeof(aa1));
				printf("Child (PID %d): Received %d from parent\n", getpid(), aa1);

				read(ports[0][0],&bb1,sizeof(bb1));
				printf("Child (PID %d): Received %d from parent\n", getpid(), bb1);
				
				int a = aa1 * bb1;
				printf("Child (PID %d): Sending %d to parent\n", getpid(), a);
				write(ports[1][1],&a,sizeof(a));

				//four - child multiply a1 and b2, send B to parent through pipe
				read(ports[0][0],&aa1,sizeof(aa1));
                                printf("Child (PID %d): Received %d from parent\n", getpid(), aa1);

                                read(ports[0][0],&bb2,sizeof(bb2));
                                printf("Child (PID %d): Received %d from parent\n", getpid(), bb2);

                                int c = aa1 * bb2;
                                printf("Child (PID %d): Sending %d to parent\n", getpid(), c);
                                write(ports[1][1],&c,sizeof(c));

				read(ports[0][0],&aa2,sizeof(aa2));
                                printf("Child (PID %d): Received %d from parent\n", getpid(), aa2);

                                read(ports[0][0],&bb1,sizeof(bb1));
                                printf("Child (PID %d): Received %d from parent\n", getpid(), bb1);
                                
                                int b = aa2 * bb1;
                                printf("Child (PID %d): Sending %d to parent\n", getpid(), b);
                                write(ports[1][1],&b,sizeof(b));
				
				read(ports[0][0],&aa2,sizeof(aa2));
                                printf("Child (PID %d): Received %d from parent\n", getpid(), aa2);

                                read(ports[0][0],&bb2,sizeof(bb2));
                                printf("Child (PID %d): Received %d from parent\n", getpid(), bb2);

                                int d = aa2 * bb2;
                                printf("Child (PID %d): Sending %d to parent\n", getpid(), d);
                                write(ports[1][1],&d,sizeof(d));
		

			}
                                
					
		}
		else {
			printf("Both inputs must be 4-digit numbers.\n");
		}
	} else {
		printf("Missing arguments.\n");
        }
}
